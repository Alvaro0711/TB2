package pe.edu.upc.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.Psicologo;
import pe.edu.upc.serviceinterfaces.IPsicologoService;

@Controller
@RequestMapping("psicologoController")
//@Secured("ROLE_ADMINISTRATOR")
public class PsicologoController {

	@Autowired
	private IPsicologoService psicologoService;

	@GetMapping("/new")
	public String newPsicologo(Model model) {
		model.addAttribute("psicologo", new Psicologo());
		return "psicologo/frmRegister";
	}

	@PostMapping("/save")
	public String savePsicologo(@Valid Psicologo psicologo, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			model.addAttribute("error", "ocurrio un error: ");
			return "psicologo/frmRegister";
		} else {
			psicologoService.insert(psicologo);
			model.addAttribute("mensaje", "se guardo correctamente");
			return "redirect:/psicologoController/new";
		}
	}

	@GetMapping("/toList")
	public String toListPsicologo(Model model) {
		try {
			model.addAttribute("listaPsicologo", psicologoService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getCause());
		}
		return "psicologo/frmList";
	}

	@RequestMapping("/delete")
	public String deletePsicologo(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if(id!=null&&id>0) {
				psicologoService.delete(id);
				model.put("listaPsicologo", psicologoService.list());//preguntar a la miss 
			} 
		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "psicologo/frmList";  
	}
	@RequestMapping("goUpdate/{id}")
	public String goUpdatePsicologo(@PathVariable int id, Model model) {
		Optional<Psicologo> psicologo =psicologoService.listId(id);
		model.addAttribute("psa", psicologo.get());
		return "psicologo/frmUpdate";
	}
	@RequestMapping("update")
	public String updatePsicologo(Psicologo psicologo) {
		psicologoService.update(psicologo);
		return "redirect:/psicologoController/toList";
	}
	
}
