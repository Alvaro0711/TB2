package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.Boleta;
import pe.edu.upc.repositories.IBoletaRepository;
import pe.edu.upc.serviceinterfaces.IBoletaService;
@Service
public class BoletaServiceimpls implements IBoletaService{
	@Autowired
	private IBoletaRepository boletaRepository;
	@Override
	public void insert(Boleta boleta) {
		boletaRepository.save(boleta);
	}

	@Override
	public List<Boleta> list() {
		return boletaRepository.findAll();
	}

	@Override
	public void delete(int idBoleta) {
		boletaRepository.deleteById(idBoleta);
	}

	@Override
	public Optional<Boleta> listId(int idBoleta) {
		return boletaRepository.findById(idBoleta);
	}

	@Override
	public void update(Boleta boleta) {
		boletaRepository.save(boleta);
	}

	@Override
	public Page<Boleta> getAll(Pageable pageable) {
		return boletaRepository.findAll(pageable);
	}

	@Override
	public List<Boleta> listNoInsertados() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void autocompletar(int cantidadInsertar) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUnrelated() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Boleta> getAllbyText(String palabraClave) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Boleta> getAllbyTextPage(Pageable pageable, String palabraClave) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boleta testNoInsertado() {
		// TODO Auto-generated method stub
		return null;
	}
	

	

}
