package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import pe.edu.upc.entities.Test;

public interface ITestService {
	public void insert(Test test);
	public List<Test> list();
	public void delete(int idTest);
	public Optional<Test> listId(int idTest);
	public void update(Test test);
	public Page<Test> getAll(Pageable pageable);
	public List<Test> listNoInsertados();
	public void autocompletar(int cantidadInsertar);
	public void deleteUnrelated();
	public List<Test> getAllbyText(String palabraClave);
	public Page<Test> getAllbyTextPage(Pageable pageable,String palabraClave);
	public Test testNoInsertado();
}
