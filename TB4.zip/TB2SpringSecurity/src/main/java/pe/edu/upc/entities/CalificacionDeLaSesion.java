package pe.edu.upc.entities;

import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CalificacionDeLaSesion")
public class CalificacionDeLaSesion {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idCalificacion;
	
	
	@Column(name="calificacion", nullable = false)
	private long calificacion;
	@Column(name="comentario", nullable = false, length=200)
	private String comentario;
	
	@OneToOne(mappedBy = "calificacion", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private SesionTerapia sesionTerapia;
	
	public CalificacionDeLaSesion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CalificacionDeLaSesion(int idCalificacion, long calificacion, String comentario) {
		super();
		this.idCalificacion = idCalificacion;
		this.calificacion = calificacion;
		this.comentario = comentario;
	}

	public int getIdCalificacion() {
		return idCalificacion;
	}

	public void setIdCalificacion(int idCalificacion) {
		this.idCalificacion = idCalificacion;
	}

	public long getCalificacion() {
		return calificacion;
	}

	public void setCalificacion(long calificacion) {
		this.calificacion = calificacion;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	
	
	public SesionTerapia getSesionTerapia() {
		return sesionTerapia;
	}

	public void setSesionTerapia(SesionTerapia sesionTerapia) {
		this.sesionTerapia = sesionTerapia;
	}

	@Override
	public int hashCode() {
		return Objects.hash(calificacion, comentario, idCalificacion);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CalificacionDeLaSesion other = (CalificacionDeLaSesion) obj;
		return calificacion == other.calificacion && Objects.equals(comentario, other.comentario)
				&& idCalificacion == other.idCalificacion;
	}
	public Boolean tieneSesion() {
		if(sesionTerapia==null) return false;
		else return false;		
	}
	
}
