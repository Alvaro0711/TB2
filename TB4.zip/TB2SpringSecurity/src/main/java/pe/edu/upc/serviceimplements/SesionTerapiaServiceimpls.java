package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.SesionTerapia;
import pe.edu.upc.repositories.ISesionTerapiaRepository;
import pe.edu.upc.serviceinterfaces.ICalificacionService;
import pe.edu.upc.serviceinterfaces.IDocumentoService;
import pe.edu.upc.serviceinterfaces.ISesionTerapiaService;
import pe.edu.upc.serviceinterfaces.ITestService;
@Service
public class SesionTerapiaServiceimpls implements ISesionTerapiaService{
	@Autowired
	private ISesionTerapiaRepository sesionTerapiaRepository;

	@Autowired
	private IDocumentoService documentoService;
	@Autowired
	private ICalificacionService calificacionSerivce;
	@Autowired
	private ITestService testService;
	@Override
	public void insert(SesionTerapia sesionTerapia) {
		// TODO Auto-generated method stub
		sesionTerapiaRepository.save(sesionTerapia);
		testService.deleteUnrelated();
		calificacionSerivce.deleteUnrelated();
		documentoService.deleteUnrelated();
	}

	@Override
	public List<SesionTerapia> list() {
		// TODO Auto-generated method stub
		return sesionTerapiaRepository.findAll();
	}

	@Override
	public void delete(int idSesion) {
		// TODO Auto-generated method stub
		sesionTerapiaRepository.deleteById(idSesion);
		testService.deleteUnrelated();
		calificacionSerivce.deleteUnrelated();
		documentoService.deleteUnrelated();
		
	}

	@Override
	public Optional<SesionTerapia> listId(int idSesion) {
		// TODO Auto-generated method stub
		return sesionTerapiaRepository.findById(idSesion);
	}

	@Override
	public void update(SesionTerapia sesionTerapia) {
		SesionTerapia auxSesionTerapia= new SesionTerapia(
				sesionTerapia.getIdSesionTerapia()
				,sesionTerapia.getPaciente(),sesionTerapia.getPsicologo()
				,sesionTerapia.getDocumento(),sesionTerapia.getCalificacion()
				,sesionTerapia.getTest(),sesionTerapia.getTitulo(),
				sesionTerapia.getDescripcion()
				,sesionTerapia.getInicioSesion(),sesionTerapia.getFinSesion()
				,sesionTerapia.getLink(),sesionTerapia.getDuracionEstmidada());
		sesionTerapiaRepository.deleteById(sesionTerapia.getIdSesionTerapia());
		sesionTerapiaRepository.save(auxSesionTerapia);
	}

}
