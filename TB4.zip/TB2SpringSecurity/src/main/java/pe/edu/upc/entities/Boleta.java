package pe.edu.upc.entities;

import java.util.Date;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="Boleta")
public class Boleta {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idBoleta;
	
	@Column(name="detalles", length=200, nullable=true)
	private String detalles;
	@Column(name="fechaDePago", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fechaDePago;
	@Column(name="monto", nullable=false)
	private double monto;
	@Column(name="metodoDePago", length=15, nullable=false)
	private String metodoDePago;
	
	@OneToOne(mappedBy = "boleta", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Suscripcion suscripcion;

	public Boleta() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Boleta(int idBoleta, String detalles, Date fechaDePago, double monto, String metodoDePago) {
		super();
		this.idBoleta = idBoleta;
		this.detalles = detalles;
		this.fechaDePago = fechaDePago;
		this.monto = monto;
		this.metodoDePago = metodoDePago;
	}

	

	public Boleta(int idBoleta, String detalles, Date fechaDePago, double monto, String metodoDePago,
			Suscripcion suscripcion) {
		super();
		this.idBoleta = idBoleta;
		this.detalles = detalles;
		this.fechaDePago = fechaDePago;
		this.monto = monto;
		this.metodoDePago = metodoDePago;
		this.suscripcion = suscripcion;
	}

	

	@Override
	public int hashCode() {
		return Objects.hash(detalles, fechaDePago, idBoleta, metodoDePago, monto, suscripcion);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Boleta other = (Boleta) obj;
		return Objects.equals(detalles, other.detalles) && Objects.equals(fechaDePago, other.fechaDePago)
				&& idBoleta == other.idBoleta && Objects.equals(metodoDePago, other.metodoDePago)
				&& Double.doubleToLongBits(monto) == Double.doubleToLongBits(other.monto)
				&& Objects.equals(suscripcion, other.suscripcion);
	}

	public int getIdBoleta() {
		return idBoleta;
	}

	public void setIdBoleta(int idBoleta) {
		this.idBoleta = idBoleta;
	}

	public String getDetalles() {
		return detalles;
	}

	public void setDetalles(String detalles) {
		this.detalles = detalles;
	}

	public Date getFechaDePago() {
		return fechaDePago;
	}

	public void setFechaDePago(Date fechaDePago) {
		this.fechaDePago = fechaDePago;
	}

	public double getMonto() {
		return monto;
	}

	public void setMonto(double monto) {
		this.monto = monto;
	}

	public String getMetodoDePago() {
		return metodoDePago;
	}

	public void setMetodoDePago(String metodoDePago) {
		this.metodoDePago = metodoDePago;
	}

	public Suscripcion getSuscripcion() {
		return suscripcion;
	}

	public void setSuscripacion(Suscripcion suscripcion) {
		this.suscripcion = suscripcion;
	}
	
	
}
