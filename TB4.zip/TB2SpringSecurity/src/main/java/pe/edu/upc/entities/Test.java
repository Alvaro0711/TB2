package pe.edu.upc.entities;

import java.util.Date;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Test")
public class Test {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idTest;
	
	@Column(name="nota", nullable = false)
	private int nota;
	@Column(name="link", nullable = false, length=200)
	private String link;
	@Column(name="horaInicio", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date horaInicio;
	@Column(name="horaFin", nullable = false)  
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date horaFin;
	
	@OneToOne(mappedBy = "test", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private SesionTerapia sesionTerapia;
	
	
	public Test() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Test(int idTest, int nota, String link, Date horaInicio, Date horaFin) {
		super();
		this.idTest = idTest;
		this.nota = nota;
		this.link = link;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
	}


	public int getIdTest() {
		return idTest;
	}

	public void setIdTest(int idTest) {
		this.idTest = idTest;
	}

	public int getNota() {
		return nota;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public Date getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Date horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Date getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}
	
	public SesionTerapia getSesionTerapia() {
		return sesionTerapia;
	}

	public void setSesionTerapia(SesionTerapia sesionTerapia) {
		this.sesionTerapia = sesionTerapia;
	}

	@Override
	public int hashCode() {
		return Objects.hash(horaFin, horaInicio, idTest, link, nota, sesionTerapia);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Test other = (Test) obj;
		return Objects.equals(horaFin, other.horaFin) && Objects.equals(horaInicio, other.horaInicio)
				&& idTest == other.idTest && Objects.equals(link, other.link) && nota == other.nota
				&& Objects.equals(sesionTerapia, other.sesionTerapia);
	}

	public Boolean tieneSesion() {
		if(sesionTerapia==null) return false;
		else return false;		
	}
	
	
	
}
