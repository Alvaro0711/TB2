package pe.edu.upc.entities;

import java.util.Date;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Suscripcion")

public class Suscripcion {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idSuscripcion;

	@ManyToOne
	@JoinColumn(name = "idPlan", nullable = false)
	private Plan plan;
	
	@OneToOne(fetch = FetchType.LAZY, orphanRemoval = true,optional = true, cascade = CascadeType.MERGE)
	@JoinColumn(name="idBoleta",  referencedColumnName = "idBoleta", nullable=true)
	private Boleta boleta;
	
	@Column(name = "fechaDeRegistro", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fechaDeRegistro;
	
	@Column(name = "meses", nullable = false)
	private int meses;
	
	@OneToOne(mappedBy = "suscripcion", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Paciente paciente;

	public Suscripcion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Suscripcion(int idSuscripcion, Plan plan, Boleta boleta, Date fechaDeRegistro, int meses) {
		super();
		this.idSuscripcion = idSuscripcion;
		this.plan = plan;
		this.boleta = boleta;
		this.fechaDeRegistro = fechaDeRegistro;
		this.meses = meses;
	}

	public Suscripcion(int idSuscripcion, Plan plan, Boleta boleta, Date fechaDeRegistro, int meses,
			Paciente paciente) {
		super();
		this.idSuscripcion = idSuscripcion;
		this.plan = plan;
		this.boleta = boleta;
		this.fechaDeRegistro = fechaDeRegistro;
		this.meses = meses;
		this.paciente = paciente;
	}

	@Override
	public int hashCode() {
		return Objects.hash(boleta, fechaDeRegistro, idSuscripcion, meses, paciente, plan);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Suscripcion other = (Suscripcion) obj;
		return Objects.equals(boleta, other.boleta) && Objects.equals(fechaDeRegistro, other.fechaDeRegistro)
				&& idSuscripcion == other.idSuscripcion && meses == other.meses
				&& Objects.equals(paciente, other.paciente) && Objects.equals(plan, other.plan);
	}

	public int getIdSuscripcion() {
		return idSuscripcion;
	}

	public void setIdSuscripcion(int idSuscripcion) {
		this.idSuscripcion = idSuscripcion;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public Boleta getBoleta() {
		return boleta;
	}

	public void setBoleta(Boleta boleta) {
		this.boleta = boleta;
	}

	public Date getFechaDeRegistro() {
		return fechaDeRegistro;
	}

	public void setFechaDeRegistro(Date fechaDeRegistro) {
		this.fechaDeRegistro = fechaDeRegistro;
	}

	public int getMeses() {
		return meses;
	}

	public void setMeses(int meses) {
		this.meses = meses;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}
	
	
	
}
