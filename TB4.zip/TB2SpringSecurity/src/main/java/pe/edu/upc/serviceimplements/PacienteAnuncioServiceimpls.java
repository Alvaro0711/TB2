//package pe.edu.upc.serviceimplements;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import pe.edu.upc.entities.PacienteAnuncio;
//import pe.edu.upc.repositories.IPacienteAnuncioRepository;
//import pe.edu.upc.serviceinterfaces.IPacienteAnuncioService;
//@Service
//public class PacienteAnuncioServiceimpls implements IPacienteAnuncioService{
//	@Autowired
//	private IPacienteAnuncioRepository pacienteAnuncioRepository;
//	@Override
//	public void insert(PacienteAnuncio pacienteAnuncio) {
//		// TODO Auto-generated method stub
//		pacienteAnuncioRepository.save(pacienteAnuncio);
//	}
//
//	@Override
//	public List<PacienteAnuncio> list() {
//		// TODO Auto-generated method stub
//		return pacienteAnuncioRepository.findAll();
//	}
//
//	@Override
//	public void delete(int idPacienteAnuncio) {
//		// TODO Auto-generated method stub
//		pacienteAnuncioRepository.deleteById(idPacienteAnuncio);
//	}
//
//	@Override
//	public Optional<PacienteAnuncio> listId(int idPacienteAnuncio) {
//		// TODO Auto-generated method stub
//		return pacienteAnuncioRepository.findById(idPacienteAnuncio);
//	}
//
//	@Override
//	public void update(PacienteAnuncio pacienteAnuncio) {
//		pacienteAnuncioRepository.save(pacienteAnuncio);
//	}
//
//
//
//}
