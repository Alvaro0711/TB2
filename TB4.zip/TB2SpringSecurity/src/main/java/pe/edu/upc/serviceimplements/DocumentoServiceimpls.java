package pe.edu.upc.serviceimplements;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.DocumentoDeTrabajo;
import pe.edu.upc.repositories.IDocumentoDeTrabajoRepository;
import pe.edu.upc.serviceinterfaces.IDocumentoService;
@Service
public class DocumentoServiceimpls implements IDocumentoService{
	@Autowired
	private IDocumentoDeTrabajoRepository documentoDeTrabajoRepository;
	@Autowired
	private SesionTerapiaServiceimpls sesionTerapiaServiceimpls;
	
	@Override
	public void insert(DocumentoDeTrabajo documentoDeTrabajo) {
		// TODO Auto-generated method stub
		documentoDeTrabajoRepository.save(documentoDeTrabajo);
	}

	@Override
	public List<DocumentoDeTrabajo> list() {
		// TODO Auto-generated method stub
		return documentoDeTrabajoRepository.findAll();
	}

	@Override
	public void delete(int idDocumentoDeTrabajo) {
		DocumentoDeTrabajo documentoDeTrabajo=documentoDeTrabajoRepository.findById(idDocumentoDeTrabajo).get();
		if(documentoDeTrabajo.getSesionTerapia()!=null) {
			sesionTerapiaServiceimpls.delete(documentoDeTrabajo.getSesionTerapia().getIdSesionTerapia());//sesionTerapiaRepository.deleteById(idTest); esta funcion busca cualquier id pk o fp para eliminar
		}
		else
			documentoDeTrabajoRepository.deleteById(idDocumentoDeTrabajo);
	}

	@Override
	public Optional<DocumentoDeTrabajo> listId(int idDocumentoDeTrabajo) {
		// TODO Auto-generated method stub
		return documentoDeTrabajoRepository.findById(idDocumentoDeTrabajo);
	}

	@Override
	public void update(DocumentoDeTrabajo documentoDeTrabajo) {
		documentoDeTrabajoRepository.save(documentoDeTrabajo);
	}


	@Override
	public Page<DocumentoDeTrabajo> getAll(Pageable pageable) {
		return documentoDeTrabajoRepository.findAll(pageable);
	}

	@Override
	public List<DocumentoDeTrabajo> listNoInsertados() {
		List<DocumentoDeTrabajo> listaNoInsertados=new ArrayList<DocumentoDeTrabajo>();
		for(DocumentoDeTrabajo documentoDeTrabajo: documentoDeTrabajoRepository.findAll()) {
			if(documentoDeTrabajo.getSesionTerapia()==null)
				listaNoInsertados.add(documentoDeTrabajo);
		}
		return listaNoInsertados;
	}

	
	@Override
	public void autocompletar(int cantidadInsertar) {
		for(int i=0;i<cantidadInsertar;i++) {
			int numero = (int)(Math.random()*100+1);
			int  titulo=(int)(Math.random()*1000+1);
			int  link=(int)(Math.random()*10000+1);
			DocumentoDeTrabajo documentoDeTrabajo=new DocumentoDeTrabajo((int)(Math.random()*1000),String.valueOf(numero),String.valueOf(titulo),String.valueOf(link));
			documentoDeTrabajoRepository.save(documentoDeTrabajo);
			
		}
	}

	@Override
	public void deleteUnrelated() {
		List<Integer> idDocumentosNoInsertados= new ArrayList<Integer>();
		for(DocumentoDeTrabajo documentoDeTrabajo: listNoInsertados()) {
			idDocumentosNoInsertados.add(documentoDeTrabajo.getIdDocumento());
		}
		for(Integer idDocumento: idDocumentosNoInsertados) {
			delete(idDocumento);
		}
	}

	@Override
	public DocumentoDeTrabajo documentoNoInsertado() {
		return listNoInsertados().get(0);
	}

}
