package pe.edu.upc.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.Rol;
import pe.edu.upc.serviceinterfaces.IRolService;

@Controller
@RequestMapping("rolController")
public class RolController {

	@Autowired
	private IRolService rolService;
	
	@GetMapping("/new")
	public String newRol(Model model) {
		model.addAttribute("rol", new Rol());
		return"rol/frmRegister";
	}
	@PostMapping("/save")
	public String saveRol(@Valid Rol rol, BindingResult binRes, Model model){
		if(binRes.hasErrors()) {
			model.addAttribute("error", "ocurrio un error en el controller de rol");
			return "rol/frmRegister";
		}else {
			rolService.insert(rol);
			model.addAttribute("mensaje", "se guardo correctamente");
			//return "redirect:/testController/new";
			return "redirect:/rolController/new";
		}  
	}
	
	@RequestMapping("/delete")
	public String deleteRol(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if(id!=null&&id>0) {
				rolService.delete(id.longValue());
				model.put("listaRol", rolService.list());//preguntar a la miss diferencia entre esto y el addatribute
			} 
		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "redirect:/rolController/toList";  
	}
	
	
	@GetMapping("/toList")
	public String toListRol(Model model) {
		try {
			model.addAttribute("listaRol", rolService.list());
			
		} catch (Exception e) {
			model.addAttribute("error", e.getCause());
		}
		return "rol/frmList";
	}
	
	@RequestMapping("/edit/{id}")
	public String editTest(@PathVariable Integer id, Model model) {
		Optional<Rol> test =rolService.listId(id.longValue());
		model.addAttribute("rolToUpdate", test.get());
		return "rol/frmUpdate";
	}
	@RequestMapping("/update")
	public String updateTest(Rol rol) {
		rolService.update(rol);
		return "redirect:/rolController/toList";
	}
}
