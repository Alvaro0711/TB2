package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entities.Plan;

public interface IPlanService {
	public void insert(Plan plan);
	public List<Plan> list();
	public void delete(int idPlan);
	
	public Optional<Plan> listId(int id);
	public void update(Plan plan);
}
