package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entities.DocumentoDeTrabajo;

public interface IDocumentoService {
	public void insert(DocumentoDeTrabajo documentoDeTrabajo);
	public List<DocumentoDeTrabajo> list();
	public void delete(int idDocumento);
	public Optional<DocumentoDeTrabajo> listId(int id);
	public void update(DocumentoDeTrabajo documentoDeTrabajo);
}
