package pe.edu.upc.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SesionTerapia")
public class SesionTerapia {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idSesionTerapia;
	@ManyToOne
	@JoinColumn(name = "idPaciente", nullable = false)
	private Paciente idPaciente;
	
	@ManyToOne
	@JoinColumn(name = "idPsicologo", nullable = false)
	private Psicologo idPsicologo;
	
	//@OneToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name="idDocumento", referencedColumnName = "idDocumento")
	@Column(name="DocumentoDeTrabajo",nullable = false, length= 50)
	private String idDocumento;
	
	//@OneToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name="idCalificacion", nullable = false)
	@Column(name="idDeLaSesion",nullable = false, length= 50)
	private String idCalificacion;
	
	//@OneToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name="idTest", nullable = false)
	@Column(name="idTest",nullable = false, length= 50)
	private String idTest;

	
	@Column(name="titulo",nullable = false, length= 50)
	private String titulo;
	@Column(name="descripcion",nullable = false, length= 200)
	private String descripcion;
	@Column(name="inicioSesion",nullable = false)
	private Date inicioSesion;
	@Column(name="finSesion",nullable = false)
	private Date finSesion;
	@Column(name="Link",nullable = false, length= 50)
	private String Link;
	@Column(name="duracionEstmidada",nullable = false)
	private Date duracionEstmidada;
	
	public SesionTerapia() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SesionTerapia(int idSesionTerapia, Paciente idPaciente, Psicologo idPsicologo, String idDocumento,
			String idCalificacion, String idTest, String titulo, String descripcion, Date inicioSesion, Date finSesion,
			String link, Date duracionEstmidada) {
		super();
		this.idSesionTerapia = idSesionTerapia;
		this.idPaciente = idPaciente;
		this.idPsicologo = idPsicologo;
		this.idDocumento = idDocumento;
		this.idCalificacion = idCalificacion;
		this.idTest = idTest;
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.inicioSesion = inicioSesion;
		this.finSesion = finSesion;
		Link = link;
		this.duracionEstmidada = duracionEstmidada;
	}

	public int getIdSesionTerapia() {
		return idSesionTerapia;
	}

	public void setIdSesionTerapia(int idSesionTerapia) {
		this.idSesionTerapia = idSesionTerapia;
	}

	public Paciente getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(Paciente idPaciente) {
		this.idPaciente = idPaciente;
	}

	public Psicologo getIdPsicologo() {
		return idPsicologo;
	}

	public void setIdPsicologo(Psicologo idPsicologo) {
		this.idPsicologo = idPsicologo;
	}

	public String getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(String idDocumento) {
		this.idDocumento = idDocumento;
	}

	public String getIdCalificacion() {
		return idCalificacion;
	}

	public void setIdCalificacion(String idCalificacion) {
		this.idCalificacion = idCalificacion;
	}

	public String getIdTest() {
		return idTest;
	}

	public void setIdTest(String idTest) {
		this.idTest = idTest;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getInicioSesion() {
		return inicioSesion;
	}

	public void setInicioSesion(Date inicioSesion) {
		this.inicioSesion = inicioSesion;
	}

	public Date getFinSesion() {
		return finSesion;
	}

	public void setFinSesion(Date finSesion) {
		this.finSesion = finSesion;
	}

	public String getLink() {
		return Link;
	}

	public void setLink(String link) {
		Link = link;
	}

	public Date getDuracionEstmidada() {
		return duracionEstmidada;
	}

	public void setDuracionEstmidada(Date duracionEstmidada) {
		this.duracionEstmidada = duracionEstmidada;
	}
	
	
}
