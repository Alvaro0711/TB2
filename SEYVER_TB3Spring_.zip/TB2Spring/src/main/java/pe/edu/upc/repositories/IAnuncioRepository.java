package pe.edu.upc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upc.entities.Anuncio;

public interface IAnuncioRepository extends JpaRepository<Anuncio, Integer>{

}
