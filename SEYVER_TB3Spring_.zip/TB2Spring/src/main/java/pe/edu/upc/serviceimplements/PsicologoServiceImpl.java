package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.serviceinterfaces.IPsicologoService;
import pe.edu.upc.entities.Psicologo;
import pe.edu.upc.repositories.IPsicologoRepository;
@Service
public class PsicologoServiceImpl implements IPsicologoService {
	@Autowired
	private IPsicologoRepository psicologoRepository;
	
	
	/*@PersistenceContext(unitName = "Avance")
	private EntityManager em;*/
	
	
	@Override
	public void insert(Psicologo ps) {
		try {
			psicologoRepository.save(ps);
		} catch (Exception e) {
			System.out.println("Error al insertar en Psicologo en el service impl");
		}
		
		
	}

	@Override
	public List<Psicologo> list() {
		return psicologoRepository.findAll();
	}

	@Override
	public void delete(int idPsicologo) {
		psicologoRepository.deleteById(idPsicologo);
	}

	@Override
	public void update(Psicologo psicologo) {
		psicologoRepository.save(psicologo);
		
	}

	/*@SuppressWarnings("unchecked")
	@Override
	public List<Psicologo> BuscarNombre(Psicologo psicologo) {
		List<Psicologo> listaPsicologos = new ArrayList<Psicologo>();
		try {
			Query jpql = em.createQuery("from Paciente p");
			listaPsicologos = (List<Psicologo>) jpql.getResultList();

		} catch (Exception e) {
			System.out.println("Error al listar psicologo en el service impl");
		}

		return listaPsicologos;
	}*/

	@Override
	public Optional<Psicologo> listId(int id) {
		// TODO Auto-generated method stub
		return psicologoRepository.findById(id);
	}
	
}
