package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entities.PacienteAnuncio;

public interface IPacienteAnuncioService {
	public void insert(PacienteAnuncio pacienteAnuncio);
	public List<PacienteAnuncio> list();
	public void delete(int idPacienteAnuncio);
	public Optional<PacienteAnuncio> listId(int id);
	public void update(PacienteAnuncio pacienteAnuncio);
}
