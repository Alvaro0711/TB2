package pe.edu.upc.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.Psicologo;
import pe.edu.upc.serviceinterfaces.IPsicologoService;

@Controller
@RequestMapping("/psicologoController")
public class PsicologoController {
	@Autowired
	private IPsicologoService perService;

	@GetMapping("/nuevo")
	public String newPsicologo(Model model) {
		model.addAttribute("psicologo", new Psicologo());
		return "/psicologo/frmRegister";
	}

	@PostMapping("/guardar")
	public String savePsicologo(@Valid Psicologo psicologo, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			model.addAttribute("error", "Ocurrió un error!!");
			System.out.println("Error al insertar en Psicologo en el controller"+ binRes.toString());
			return "/psicologo/frmRegister";
		} else {
			perService.insert(psicologo);
			model.addAttribute("mensaje", "Se guardó correctamente!!");
			return "redirect:/psicologoController/nuevo";
		}

	}

	@GetMapping("/listar")
	public String listPsicologo(Model model) {
		try {
			model.addAttribute("listaPersonas", perService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/psicologo/frmList";
	}
	@RequestMapping("/eliminar")
	public String deletePsicologo(Map<String,Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if(id!=null && id>0) {
				perService.delete(id);
				model.put("listaPersonas", perService.list());
			}
		} catch (Exception e) {
			// TODO: handle exception
			model.put("error", e.getMessage());
		}
		return "/psicologo/frmList";
	}
	@RequestMapping("irmodificar/{id}")
	public String goUpdatePsicologo(@PathVariable int id,Model model) {
		Optional<Psicologo> objPer=perService.listId(id);
		model.addAttribute("psicologoEncontrado",objPer.get());
		return "/psicologo/frmUpdate";
	}

	@PostMapping("/modificar")
	public String updatePerson(Psicologo psicologo) {
		perService.update(psicologo);		
		return "redirect:/psicologoController/listar";
	}
	

}
