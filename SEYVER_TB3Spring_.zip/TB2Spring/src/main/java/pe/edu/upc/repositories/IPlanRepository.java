package pe.edu.upc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upc.entities.Plan;

public interface IPlanRepository extends JpaRepository<Plan, Integer>{

}
