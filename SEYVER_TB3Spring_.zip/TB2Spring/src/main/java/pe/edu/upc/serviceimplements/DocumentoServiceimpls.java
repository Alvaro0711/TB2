package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.DocumentoDeTrabajo;
import pe.edu.upc.repositories.IDocumentoDeTrabajoRepository;
import pe.edu.upc.serviceinterfaces.IDocumentoService;
@Service
public class DocumentoServiceimpls implements IDocumentoService{
	@Autowired
	private IDocumentoDeTrabajoRepository iDocumentoDeTrabajoRepository;
	@Override
	public void insert(DocumentoDeTrabajo ps) {
		// TODO Auto-generated method stub
		iDocumentoDeTrabajoRepository.save(ps);
	}

	@Override
	public List<DocumentoDeTrabajo> list() {
		// TODO Auto-generated method stub
		return iDocumentoDeTrabajoRepository.findAll();
	}

	@Override
	public void delete(int idDocumento) {
		// TODO Auto-generated method stub
		iDocumentoDeTrabajoRepository.deleteById(idDocumento);
	}
	@Override
	public Optional<DocumentoDeTrabajo> listId(int idDocumento) {
		// TODO Auto-generated method stub
		return iDocumentoDeTrabajoRepository.findById(idDocumento);
	}

	@Override
	public void update(DocumentoDeTrabajo documentoDeTrabajo) {
		// TODO Auto-generated method stub
		iDocumentoDeTrabajoRepository.save(documentoDeTrabajo);
	}
}
