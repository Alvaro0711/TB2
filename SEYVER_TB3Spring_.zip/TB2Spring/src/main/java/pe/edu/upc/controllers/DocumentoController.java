package pe.edu.upc.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.DocumentoDeTrabajo;
import pe.edu.upc.serviceinterfaces.IDocumentoService;

@Controller
@RequestMapping("/documentoController")
public class DocumentoController {
	@Autowired
	private IDocumentoService documentoService;
	

		
		//metodos
		@GetMapping("/nuevo")
		public String newDocumento(Model model) {
			model.addAttribute("documento", new DocumentoDeTrabajo());
			return "/documento/frmRegister";
		}
		
		@PostMapping("/guardar")
		public String saveDocumento(@Valid DocumentoDeTrabajo pe, BindingResult binRes, Model model) {
			if (binRes.hasErrors()) {
				model.addAttribute("error", "Ocurrió un error en el controller de trabajo!!");
				return "/documento/frmRegister";
			} else {
				documentoService.insert(pe);
				model.addAttribute("mensaje", "Se guardó correctamente  en el controller de trabajo!!");
				return "redirect:/documentoController/nuevo";
			}

		}
		@GetMapping("/listar")
		public String listDocumento(Model model) {
			try {
				model.addAttribute("listaDocumentoDeTrabajo", documentoService.list());
			} catch (Exception e) {
				model.addAttribute("error", e.getMessage());
			}

			return "/documento/frmList";
		}
		@RequestMapping("/eliminar")
		public String deleteDocumento(Map<String,Object> model, @RequestParam(value = "id") Integer id) {
			try {
				if(id!=null && id>0) {
					documentoService.delete(id);
					model.put("listaDocumentoDeTrabajo", documentoService.list());
				}
			} catch (Exception e) {
				// TODO: handle exception
				model.put("error", e.getMessage());
			}
			return "/documento/frmList";
		}
		
		
		@RequestMapping("irmodificar/{id}")
		public String goUpdateDocumentoDeTrabajo(@PathVariable int id,Model model) {
			Optional<DocumentoDeTrabajo> objPer=documentoService.listId(id);
			model.addAttribute("psa",objPer.get());
			return "/documento/frmUpdate";
		}
		@PostMapping("/modificar")
		public String updateDocumentoDeTrabajo(DocumentoDeTrabajo documentoDeTrabajo) {
			return "redirect:/documentoController/listar";
		}

}
