package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.serviceinterfaces.IPacienteService;
import pe.edu.upc.entities.Paciente;
import pe.edu.upc.repositories.IPacienteRepository;

@Service
public class PacienteServiceImpl implements IPacienteService {
	
	@Autowired
	private IPacienteRepository iPacienteRepository;

	@Override
	public void insert(Paciente paciente) {
		iPacienteRepository.save(paciente);
	}

	@Override
	public List<Paciente> list() {
		// TODO Auto-generated method stub
		return iPacienteRepository.findAll();
	}

	@Override
	public void delete(int idPaciente) {
		iPacienteRepository.deleteById(idPaciente);
	}

	@Override
	public Optional<Paciente> listId(int idPaciente) {
		// TODO Auto-generated method stub
		return iPacienteRepository.findById(idPaciente);
	}

	@Override
	public void update(Paciente paciente) {
		// TODO Auto-generated method stub
		iPacienteRepository.save(paciente);
	}
}
