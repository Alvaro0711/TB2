package pe.edu.upc.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CalificacionDeLaSesion")
public class CalificacionDeLaSesion {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idCalificacion;
	
	
	@Column(name="calificacion", nullable = false)
	private long calificacion;
	@Column(name="comentario", nullable = false, length=200)
	private String comentario;
	
	//@OneToOne(mappedBy = "idCalificacion")
	@Column(name="comentario", nullable = false, length=200)
	private String sesionterapia;
	
	public CalificacionDeLaSesion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CalificacionDeLaSesion(int idCalificacion, long calificacion, String comentario, String sesionterapia) {
		super();
		this.idCalificacion = idCalificacion;
		this.calificacion = calificacion;
		this.comentario = comentario;
		this.sesionterapia = sesionterapia;
	}

	public int getIdCalificacion() {
		return idCalificacion;
	}

	public void setIdCalificacion(int idCalificacion) {
		this.idCalificacion = idCalificacion;
	}

	public long getCalificacion() {
		return calificacion;
	}

	public void setCalificacion(long calificacion) {
		this.calificacion = calificacion;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public String getSesionterapia() {
		return sesionterapia;
	}

	public void setSesionterapia(String sesionterapia) {
		this.sesionterapia = sesionterapia;
	}
	
	
}
