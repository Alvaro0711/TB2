package pe.edu.upc.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Anuncio")
public class Anuncio {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idAnuncio;
	@ManyToOne
	@JoinColumn(name="idPsicologo",nullable = false)
	private Psicologo idPsicologo;
	
	@ManyToOne
	@JoinColumn(name="idPacienteAnuncio",nullable = false)
	private PacienteAnuncio idPacienteAnuncio;
	
	@Column(name="titulo", nullable = false, length=50)
	private String titulo;
	@Column(name="descripcion", nullable = false, length=100)
	private String descripcion;
	@Column(name="fecha", nullable = false)
	private Date fecha;
//	@Column(name="visible", nullable = false)
//	private Boolean visible;
	public Anuncio() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Anuncio(int idAnuncio, Psicologo idPsicologo, PacienteAnuncio idPacienteAnuncio, String titulo,
		String descripcion, Date fecha) {
	super();
	this.idAnuncio = idAnuncio;
	this.idPsicologo = idPsicologo;
	this.idPacienteAnuncio = idPacienteAnuncio;
	this.titulo = titulo;
	this.descripcion = descripcion;
	this.fecha = fecha;
}

	public int getIdAnuncio() {
		return idAnuncio;
	}
	public void setIdAnuncio(int idAnuncio) {
		this.idAnuncio = idAnuncio;
	}
	public Psicologo getIdPsicologo() {
		return idPsicologo;
	}
	public void setIdPsicologo(Psicologo idPsicologo) {
		this.idPsicologo = idPsicologo;
	}
	public PacienteAnuncio getIdPacienteAnuncio() {
		return idPacienteAnuncio;
	}
	public void setIdPacienteAnuncio(PacienteAnuncio idPacienteAnuncio) {
		this.idPacienteAnuncio = idPacienteAnuncio;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
//	public Boolean getVisible() {
//		return visible;
//	}
//	public void setVisible(Boolean visible) {
//		this.visible = visible;
//	}
	
	
}
