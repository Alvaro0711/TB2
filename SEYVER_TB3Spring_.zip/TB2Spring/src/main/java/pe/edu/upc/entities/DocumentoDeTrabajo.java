package pe.edu.upc.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DocumentoDeTrabajo")
public class DocumentoDeTrabajo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idDocumento;
	
	@Column(name="tipo",nullable = false, length= 15)
	private String tipo;
	@Column(name="titulo",nullable = false, length= 50)
	private String titulo;
	@Column(name="link",nullable = false, length= 50)
	private String link;
	
	//@OneToOne(mappedBy = "idDocumento")
	@Column(name="SesionTerapia",nullable = false, length= 50)
	private String sesionTerapia;
	
	public DocumentoDeTrabajo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DocumentoDeTrabajo(int idDocumento, String tipo, String titulo, String link, String sesionTerapia) {
		super();
		this.idDocumento = idDocumento;
		this.tipo = tipo;
		this.titulo = titulo;
		this.link = link;
		this.sesionTerapia = sesionTerapia;
	}

	public int getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(int idDocumento) {
		this.idDocumento = idDocumento;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getSesionTerapia() {
		return sesionTerapia;
	}

	public void setSesionTerapia(String sesionTerapia) {
		this.sesionTerapia = sesionTerapia;
	}
	
}
