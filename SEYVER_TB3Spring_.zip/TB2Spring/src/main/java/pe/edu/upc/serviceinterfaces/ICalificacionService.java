package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entities.CalificacionDeLaSesion;

public interface ICalificacionService {
	public void insert(CalificacionDeLaSesion calificacionDeLaSesion);
	public List<CalificacionDeLaSesion> list();
	public void delete(int idCalificacion);
	public Optional<CalificacionDeLaSesion> listId(int id);
	public void update(CalificacionDeLaSesion calificacionDeLaSesion);
}
