package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entities.Anuncio;

public interface IAnuncioService {
	public void insert(Anuncio anuncio);
	public List<Anuncio> list();
	public void delete(int idAnuncio);
	public Optional<Anuncio> listId(int id);
	public void update(Anuncio anuncio);
}
