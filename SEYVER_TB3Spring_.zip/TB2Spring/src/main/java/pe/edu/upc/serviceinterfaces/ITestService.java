package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entities.Test;

public interface ITestService {
	public void insert(Test test);
	public List<Test> list();
	public void delete(int idTest);
	public Optional<Test> listId(int id);
	public void update(Test test);
}
