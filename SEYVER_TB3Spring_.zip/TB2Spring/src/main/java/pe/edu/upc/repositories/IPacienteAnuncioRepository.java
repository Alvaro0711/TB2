package pe.edu.upc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upc.entities.PacienteAnuncio;

public interface IPacienteAnuncioRepository extends JpaRepository<PacienteAnuncio, Integer>{

}
