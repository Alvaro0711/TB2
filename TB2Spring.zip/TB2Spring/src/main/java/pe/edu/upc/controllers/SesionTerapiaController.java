package pe.edu.upc.controllers;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.Paciente;
import pe.edu.upc.entities.Psicologo;
import pe.edu.upc.entities.SesionTerapia;
import pe.edu.upc.serviceinterfaces.IPacienteService;
import pe.edu.upc.serviceinterfaces.IPsicologoService;
import pe.edu.upc.serviceinterfaces.ISesionTerapiaService;

@Controller
@RequestMapping("/sesionTerapiaController")
public class SesionTerapiaController {
	@Autowired
	private ISesionTerapiaService sesionTerapiaService;
	@Autowired
	private IPsicologoService psicologoService;
	@Autowired
	private IPacienteService pacienteService;
	
	
	// Variables
	//private SesionTerapia sesionTerapia;
	List<Psicologo> listaPsicologos;
	List<Paciente> listaPacientes;

	@PostConstruct
	public void init() {
		//this.sesionTerapia = new SesionTerapia();
		this.listPsicologos();
		this.listPacientes();
	}

	// metodos
	@GetMapping("/nuevo")
	public String newSesion(Model model) {
		model.addAttribute("sesion", new SesionTerapia());
		return "/sesion/frmRegister";
	}

	@PostMapping("/guardar")
	public String saveSesion(@Valid SesionTerapia sesionTerapia, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			model.addAttribute("error", "Ocurrió un error!!");
			return "/sesion/frmRegister";
		} else {
			sesionTerapiaService.insert(sesionTerapia);
			model.addAttribute("mensaje", "Se guardó correctamente!!");
			return "redirect:/sesionTerapiaController/nuevo";
		}
	}

	@GetMapping("/listar")
	public String listSesion(Model model) {
		try {
			model.addAttribute("listaSesiones", sesionTerapiaService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/sesion/frmList";
	}

	@RequestMapping("/eliminar")
	public String deleteSesion(Map<String,Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if(id!=null && id>0) {
				sesionTerapiaService.delete(id);
				model.put("listaSesiones", sesionTerapiaService.list());
			}
		} catch (Exception e) {
			// TODO: handle exception
			model.put("error", e.getMessage());
		}
		return "/sesion/frmList";
	}

	@RequestMapping("irmodificar/{id}")
	public String goUpdateSesion(@PathVariable int id,Model model) {
		Optional<SesionTerapia> objPer=sesionTerapiaService.listId(id);
		model.addAttribute("psa",objPer.get());
		return "/sesion/frmUpdate";
	}
	@PostMapping("/modificar")
	public String updateSesion(SesionTerapia sesionTerapia) {
		sesionTerapiaService.update(sesionTerapia);		
		return "redirect:/sesionTerapiaController/listar";
	}
	
	
	public void listPsicologos() {
		try {
			listaPsicologos=psicologoService.list();
		} catch (Exception e) {
			System.out.println("Error al listar en el controlloer de Psicologos");
		}
	}

	public void listPacientes() {
		try {
			listaPacientes = pacienteService.list();
		} catch (Exception e) {
			System.out.println("Error al listar en el controlloer de Pacientes");
		}
	}

	/*public SesionTerapia getSt() {
		return sesionTerapia;
	}

	public void setSt(SesionTerapia sesionTerapia) {
		this.sesionTerapia = sesionTerapia;
	}

	public List<SesionTerapia> getListaSesiones() {
		return listaSesiones;
	}

	public void setListaSesiones(List<SesionTerapia> listaSesiones) {
		this.listaSesiones = listaSesiones;
	}*/

	public List<Psicologo> getListaPsicologos() {
		return listaPsicologos;
	}

	public void setListaPsicologos(List<Psicologo> listaPsicologos) {
		this.listaPsicologos = listaPsicologos;
	}

	public List<Paciente> getListaPacientes() {
		return listaPacientes;
	}

	public void setListaPacientes(List<Paciente> listaPacientes) {
		this.listaPacientes = listaPacientes;
	}

}
