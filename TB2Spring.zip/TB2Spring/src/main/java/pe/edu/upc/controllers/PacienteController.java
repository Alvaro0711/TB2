package pe.edu.upc.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.Paciente;
import pe.edu.upc.serviceinterfaces.IPacienteService;

@Controller
@RequestMapping("/pacienteController")
public class PacienteController {
	
	@Autowired
	private IPacienteService pacienteService;
	
	//metodos
	@GetMapping("/nuevo")
	public String newPaciente(Model model) {
		model.addAttribute("paciente", new Paciente());
		return "/paciente/frmRegister";
	}
	
	@PostMapping("/guardar")
	public String savePaciente(@Valid Paciente paciente, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			model.addAttribute("error", "Ocurrió un error en paciente controller!!");
			return "/paciente/frmRegister";
		} else {
			pacienteService.insert(paciente);
			model.addAttribute("mensaje", "Se guardó correctamente en paciente controller!!");
			return "redirect:/pacienteController/nuevo";
		}

	}

	@GetMapping("/listar")
	public String listPaciente(Model model) {
		try {
			model.addAttribute("listaPacientes", pacienteService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/paciente/frmList";
	}
	@RequestMapping("/eliminar")
	public String deletePaciente(Map<String,Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if(id!=null && id>0) {
				pacienteService.delete(id);
				model.put("listaPacientes", pacienteService.list());
			}
		} catch (Exception e) {
			// TODO: handle exception
			model.put("error", e.getMessage());
		}
		return "/paciente/frmList";
	}
	
	
	@RequestMapping("irmodificar/{id}")
	public String goUpdatePaciente(@PathVariable int id,Model model) {
		Optional<Paciente> objPer=pacienteService.listId(id);
		model.addAttribute("psa",objPer.get());
		return "person/frmUpdate";
	}
	@PostMapping("/modificar")
	public String updatePaciente(Paciente paciente) {
		pacienteService.update(paciente);		
		return "redirect:/personitas/listar";
	}



}