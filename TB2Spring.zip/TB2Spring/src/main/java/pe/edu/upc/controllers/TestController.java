package pe.edu.upc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.Test;
import pe.edu.upc.repositories.ITestRepository;
import pe.edu.upc.serviceinterfaces.ITestService;

@Controller
@RequestMapping("/testController")
public class TestController {
	@Autowired
	private ITestRepository testRepository;

	@GetMapping("/nuevo")
	public String newTest(Model model) {
		model.addAttribute("test", new Test());
		return "/test/frmRegister";
	}

	@PostMapping("/guardar")
	public String saveTest(@Valid Test test, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			model.addAttribute("error", "Ocurrió un error!!");
			return "/test/frmRegister";
		} else {
			//testRepository.insert(Test);
			model.addAttribute("mensaje", "Se guardó correctamente!!");
			return "redirect:/testController/nuevo";
		}

	}

	@GetMapping("/listar")
	public String listTest(Model model) {
		try {
			//model.addAttribute("listaTests", testRepository.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/person/frmList";
	}
	@RequestMapping("/eliminar")
	public String deleteTest(Map<String,Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if(id!=null && id>0) {
				//testRepository.delete(id);
				//model.put("listaTests", testRepository.list());
			}
		} catch (Exception e) {
			// TODO: handle exception
			model.put("error", e.getMessage());
		}
		return "/test/frmList";
	}
	
	
	@RequestMapping("irmodificar/{id}")
	public String goUpdateTest(@PathVariable int id,Model model) {
		//Optional<Test> objPer=testRepository.listId(id);
		//model.addAttribute("psa",objPer.get());
		return "/test/frmUpdate";
	}
	@PostMapping("/modificar")
	public String updatePerson(Test test) {
		//testRepository.update(test);		
		return "redirect:/testController/listar";
	}

}
