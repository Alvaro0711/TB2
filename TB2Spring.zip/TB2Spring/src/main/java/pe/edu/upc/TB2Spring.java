package pe.edu.upc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TB2Spring {

	public static void main(String[] args) {
		SpringApplication.run(TB2Spring.class, args);
	}

}
