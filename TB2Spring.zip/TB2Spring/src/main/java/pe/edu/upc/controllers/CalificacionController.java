package pe.edu.upc.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.CalificacionDeLaSesion;
import pe.edu.upc.serviceinterfaces.ICalificacionService;

@Controller
@RequestMapping("/calificacionController")
public class CalificacionController {
	@Autowired
	private ICalificacionService calificacionService;
	
	@GetMapping("/nuevo")
	public String newCalificacionDeLaSesion(Model model) {
		model.addAttribute("calificacion", new CalificacionDeLaSesion());
		return "/calificacion/frmRegister";
	}

	@PostMapping("/guardar")
	public String saveCalificacionDeLaSesion(@Valid CalificacionDeLaSesion calificacion, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			model.addAttribute("error", "Ocurrió un error en el controller de calificacion!!");
			return "/calificacion/frmRegister";
		} else {
			calificacionService.insert(calificacion);
			model.addAttribute("mensaje", "Se guardó correctamente en el controller de calificacion!!");
			return "redirect:/calificacionController/nuevo";
		}

	}

	@GetMapping("/listar")
	public String listCalificaciones(Model model) {
		try {
			model.addAttribute("listaCalificaciones", calificacionService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/calificacion/frmList";
	}
	@RequestMapping("/eliminar")
	public String deleteCalificacionDeLaSesion(Map<String,Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if(id!=null && id>0) {
				calificacionService.delete(id);
				model.put("listacalificaciones", calificacionService.list());
			}
		} catch (Exception e) {
			// TODO: handle exception
			model.put("error", e.getMessage());
		}
		return "/calificacion/frmList";
	}
	
	
	@RequestMapping("irmodificar/{id}")
	public String goUpdateCalificacionDeLaSesion(@PathVariable int id,Model model) {
		Optional<CalificacionDeLaSesion> objPer=calificacionService.listId(id);
		model.addAttribute("psa",objPer.get());
		return "/calificacion/frmUpdate";
	}
	@PostMapping("/modificar")
	public String updateCalificacionDeLaSesion(CalificacionDeLaSesion calificacionDeLaSesion) {
		calificacionService.update(calificacionDeLaSesion);		
		return "redirect:/calificacionController/listar";
	}

}
