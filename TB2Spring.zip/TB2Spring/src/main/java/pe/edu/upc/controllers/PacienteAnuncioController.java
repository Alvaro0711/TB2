package pe.edu.upc.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entities.Anuncio;
import pe.edu.upc.entities.Paciente;
import pe.edu.upc.entities.PacienteAnuncio;
import pe.edu.upc.serviceinterfaces.IAnuncioService;
import pe.edu.upc.serviceinterfaces.IPacienteAnuncioService;
import pe.edu.upc.serviceinterfaces.IPacienteService;

@Named
@RequestScoped
public class PacienteAnuncioController {
	@Inject
	private IPacienteAnuncioService paService;
	@Inject
	private IAnuncioService aService;
	@Inject
	private IPacienteService pService;
	
	//Variables
	private PacienteAnuncio pa;
	List<PacienteAnuncio> listaPacientesAnuncios;
	
	List<Anuncio> listaAnuncios;
	List<Paciente> listaPaciente;
	
	//Constructor
		@PostConstruct
		public void init() {
			this.listaPacientesAnuncios = new ArrayList<PacienteAnuncio>();
			this.pa = new PacienteAnuncio();
			this.listAnuncios();
			this.listPacientes();
			this.list();
		}
		
		//metodos
		public String newPsicologo() {
			this.setPa(new PacienteAnuncio());
			return "pacienteAnuncio.xhtml";
		}
		
		public void insert() {
			try {
				paService.insert(pa);
			}catch(Exception e) {
				System.out.println("Error al insertar en el controller de PacienteAnuncio");
			}
		}
		
		public void list() {
			try {
				listaPacientesAnuncios = paService.list();
			}catch(Exception e) {
				System.out.println("Error al listar en el controlloer de PacienteAnuncio");
			}
		}
		
		public void listAnuncios() {
			try {
				listaAnuncios = aService.list();
			}catch(Exception e) {
				System.out.println("Error al listar en el controlloer de Anuncio");
			}
		}
		
		public void listPacientes() {
			try {
				listaPaciente = pService.list();
			}catch(Exception e) {
				System.out.println("Error al listar en el controlloer de Paciente");
			}
		}
		
		
		public void delete(PacienteAnuncio psi) {
			try {
				paService.delete(psi.getIdPacienteAnuncio());
				this.list();
			}catch (Exception e) {
				System.out.println("Error al eliminar el controlador PacienteAnuncio");
			}
		}
		
	
	public PacienteAnuncio getPa() {
		return pa;
	}
	public void setPa(PacienteAnuncio pa) {
		this.pa = pa;
	}
	public List<PacienteAnuncio> getListaPacientesAnuncios() {
		return listaPacientesAnuncios;
	}
	public void setListaPacientesAnuncios(List<PacienteAnuncio> listaPacientesAnuncios) {
		this.listaPacientesAnuncios = listaPacientesAnuncios;
	}

	public List<Anuncio> getListaAnuncios() {
		return listaAnuncios;
	}

	public void setListaAnuncios(List<Anuncio> listaAnuncios) {
		this.listaAnuncios = listaAnuncios;
	}

	public List<Paciente> getListaPaciente() {
		return listaPaciente;
	}

	public void setListaPaciente(List<Paciente> listaPaciente) {
		this.listaPaciente = listaPaciente;
	}
	
}
