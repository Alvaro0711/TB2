package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.CalificacionDeLaSesion;
import pe.edu.upc.repositories.ICalificacionDeLaSesionRepository;
import pe.edu.upc.serviceinterfaces.ICalificacionService;


@Service
public class CalificacionServiceImpl implements ICalificacionService{
	@Autowired
	private ICalificacionDeLaSesionRepository iCalificacionDeLaSesionRepository;
	
	@Override
	public void insert(CalificacionDeLaSesion ps) {
		// TODO Auto-generated method stub
		iCalificacionDeLaSesionRepository.save(ps);
	}

	@Override
	public List<CalificacionDeLaSesion> list() {
		// TODO Auto-generated method stub
		return iCalificacionDeLaSesionRepository.findAll();
	}

	@Override
	public void delete(int idCalificacion) {
		// TODO Auto-generated method stub
		iCalificacionDeLaSesionRepository.deleteById(idCalificacion);
	}
	
	@Override
	public Optional<CalificacionDeLaSesion> listId(int idCalificacionDeLaSesion) {
		// TODO Auto-generated method stub
		return iCalificacionDeLaSesionRepository.findById(idCalificacionDeLaSesion);
	}

	@Override
	public void update(CalificacionDeLaSesion calificacionDeLaSesion) {
		// TODO Auto-generated method stub
		iCalificacionDeLaSesionRepository.save(calificacionDeLaSesion);
	}

}
