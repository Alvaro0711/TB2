package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.Test;
import pe.edu.upc.repositories.ITestRepository;
import pe.edu.upc.serviceinterfaces.ITestService;

@Service
public class TestServiceimpls implements ITestService{
	@Autowired
	private ITestRepository iTestRepository;
	@Override
	public void insert(Test ps) {
		// TODO Auto-generated method stub
		iTestRepository.save(ps);
	}

	@Override
	public List<Test> list() {
		// TODO Auto-generated method stub
		return iTestRepository.findAll();
	}

	@Override
	public void delete(int idPerson) {
		// TODO Auto-generated method stub
		iTestRepository.deleteById(idPerson);
	}

	@Override
	public Optional<Test> listId(int idTest) {
		// TODO Auto-generated method stub
		return iTestRepository.findById(idTest);
	}

	@Override
	public void update(Test test) {
		// TODO Auto-generated method stub
		iTestRepository.save(test);
	}

}
