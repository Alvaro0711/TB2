package pe.edu.upc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upc.entities.CalificacionDeLaSesion;

public interface ICalificacionDeLaSesionRepository extends JpaRepository<CalificacionDeLaSesion, Integer>{

}
