package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.Anuncio;
import pe.edu.upc.repositories.IAnuncioRepository;
import pe.edu.upc.serviceinterfaces.IAnuncioService;
@Service
public class AnuncioServiceimpls implements IAnuncioService{
	@Autowired
	private IAnuncioRepository iAnuncioRepository;
	@Override
	public void insert(Anuncio anuncio) {
		// TODO Auto-generated method stub
		iAnuncioRepository.save(anuncio);
	}

	@Override
	public List<Anuncio> list() {
		// TODO Auto-generated method stub
		return iAnuncioRepository.findAll();
	}

	@Override
	public void delete(int idAnuncio) {
		// TODO Auto-generated method stub
		iAnuncioRepository.deleteById(idAnuncio);
	}
	@Override
	public Optional<Anuncio> listId(int idAnuncio) {
		// TODO Auto-generated method stub
		return iAnuncioRepository.findById(idAnuncio);
	}

	@Override
	public void update(Anuncio anuncio) {
		// TODO Auto-generated method stub
		iAnuncioRepository.save(anuncio);
	}
}
