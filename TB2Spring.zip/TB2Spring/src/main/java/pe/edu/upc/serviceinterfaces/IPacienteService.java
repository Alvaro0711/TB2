package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entities.Paciente;

public interface IPacienteService {
	public void insert(Paciente paciente);

	public List<Paciente> list();
	
	public void delete(int idPaciente);
	
	public Optional<Paciente> listId(int id);
	public void update(Paciente paciente);
}
