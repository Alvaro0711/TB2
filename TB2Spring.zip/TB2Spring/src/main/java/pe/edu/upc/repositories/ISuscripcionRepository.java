package pe.edu.upc.repositories;

public interface ISuscripcionRepository{

}
