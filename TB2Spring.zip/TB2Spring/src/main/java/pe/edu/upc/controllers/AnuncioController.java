package pe.edu.upc.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import pe.edu.upc.entities.Anuncio;
//import pe.edu.upc.entities.Paciente;
import pe.edu.upc.entities.PacienteAnuncio;
import pe.edu.upc.entities.Psicologo;
import pe.edu.upc.serviceinterfaces.IAnuncioService;
import pe.edu.upc.serviceinterfaces.IPacienteAnuncioService;
//import pe.edu.upc.serviceinterfaces.IPacienteService;
import pe.edu.upc.serviceinterfaces.IPsicologoService;

@Controller
@RequestMapping("/anuncioController")
public class AnuncioController {
	@Inject
	private IAnuncioService psService;
	@Inject 
	private IPsicologoService pService;
	@Inject
	private IPacienteAnuncioService paService;
	//Variables
	private Anuncio a;
	List<Anuncio> listaAnuncios;
	
	List<Psicologo> listaPsicologos;
	List<PacienteAnuncio> listaPacientexAnuncio;
	
	//Constructor
		@PostConstruct
		public void init() {
			this.listaAnuncios = new ArrayList<Anuncio>();
			this.a = new Anuncio();
			this.listPsicologos();
			this.listPacienteXAnuncio();
			this.list();
		}
		
		//metodos
		public String newPsicologo() {
			this.setA(new Anuncio());
			return "anuncio.xhtml";
		}
		
		public void insert() {
			try {
				psService.insert(a);
			}catch(Exception e) {
				System.out.println("Error al insertar en el controller de Anuncio");
			}
		}
		
		public void list() {
			try {
				listaAnuncios = psService.list();
			}catch(Exception e) {
				System.out.println("Error al listar en el controlloer de Anuncio");
			}
		}
		
		public void listPsicologos() {
			try {
				listaPsicologos=pService.list();
			} catch (Exception e) {
				System.out.println("Error al listar en el controlloer de Psicologos");
			}
		}

		public void listPacienteXAnuncio() {
			try {
				listaPacientexAnuncio = paService.list();
			} catch (Exception e) {
				System.out.println("Error al listar en el controlloer de Pacientes");
			}
		}
		
		public void delete(Anuncio psi) {
			try {
				psService.delete(psi.getIdAnuncio());
				this.list();
			}catch (Exception e) {
				System.out.println("Error al eliminar el controlador Anuncio");
			}
		}
		
	
	public Anuncio getA() {
		return a;
	}
	public void setA(Anuncio a) {
		this.a = a;
	}
	public List<Anuncio> getListaAnuncios() {
		return listaAnuncios;
	}
	public void setListaAnuncios(List<Anuncio> listaAnuncios) {
		this.listaAnuncios = listaAnuncios;
	}

	public List<Psicologo> getListaPsicologos() {
		return listaPsicologos;
	}

	public void setListaPsicologos(List<Psicologo> listaPsicologos) {
		this.listaPsicologos = listaPsicologos;
	}

	public List<PacienteAnuncio> getListaPacientexAnuncio() {
		return listaPacientexAnuncio;
	}

	public void setListaPacientexAnuncio(List<PacienteAnuncio> listaPacientexAnuncio) {
		this.listaPacientexAnuncio = listaPacientexAnuncio;
	}
	
}
