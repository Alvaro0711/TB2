package pe.edu.upc.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Test")
public class Test {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idTest;
	
//	@Column(name="esEvaluacion", nullable = false)
//	private Boolean esEvaluacion;
	@Column(name="nota", nullable = false)
	private int nota;
	@Column(name="link", nullable = false, length=200)
	private String link;
//	@Column(name="Habilitado", nullable = false)
//	private Boolean Habilitado;
	@Column(name="horaInicio", nullable = false)
	private Date horaInicio;
	@Column(name="horaFin", nullable = false)
	private Date horaFin;
	
	//@OneToOne(mappedBy = "idTest")
	@Column(name="link", nullable = false, length=200)
	private String sesionterapia;
	
	public Test() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Test(int idTest, int nota, String link, Date horaInicio, Date horaFin, String sesionterapia) {
		super();
		this.idTest = idTest;
		this.nota = nota;
		this.link = link;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
		this.sesionterapia = sesionterapia;
	}



	public int getIdTest() {
		return idTest;
	}

	public void setIdTest(int idTest) {
		this.idTest = idTest;
	}


	public int getNota() {
		return nota;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}


	public Date getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Date horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Date getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}

	public String getSesionterapia() {
		return sesionterapia;
	}

	public void setSesionterapia(String sesionterapia) {
		this.sesionterapia = sesionterapia;
	}
	
	
	
}
