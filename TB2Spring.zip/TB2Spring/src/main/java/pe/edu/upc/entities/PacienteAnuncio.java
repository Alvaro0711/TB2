package pe.edu.upc.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PacienteAnuncio")
public class PacienteAnuncio {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idPacienteAnuncio;
	
	@ManyToOne
	@JoinColumn(name="idAnuncio",nullable = false)
	private Anuncio idAnuncio;
	
	@ManyToOne
	@JoinColumn(name="idPaciente",nullable = false)
	private Paciente idPaciente;

	public PacienteAnuncio() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PacienteAnuncio(int idPacienteAnuncio, Anuncio idAnuncio, Paciente idPaciente) {
		super();
		this.idPacienteAnuncio = idPacienteAnuncio;
		this.idAnuncio = idAnuncio;
		this.idPaciente = idPaciente;
	}

	public int getIdPacienteAnuncio() {
		return idPacienteAnuncio;
	}

	public void setIdPacienteAnuncio(int idPacienteAnuncio) {
		this.idPacienteAnuncio = idPacienteAnuncio;
	}

	public Anuncio getIdAnuncio() {
		return idAnuncio;
	}

	public void setIdAnuncio(Anuncio idAnuncio) {
		this.idAnuncio = idAnuncio;
	}

	public Paciente getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(Paciente idPaciente) {
		this.idPaciente = idPaciente;
	}

	
	
}
