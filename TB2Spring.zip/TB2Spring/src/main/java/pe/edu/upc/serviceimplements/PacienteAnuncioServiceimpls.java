package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import pe.edu.upc.entities.PacienteAnuncio;
import pe.edu.upc.repositories.IPacienteAnuncioRepository;
import pe.edu.upc.serviceinterfaces.IPacienteAnuncioService;
@Service
public class PacienteAnuncioServiceimpls implements IPacienteAnuncioService{
	@Autowired
	private IPacienteAnuncioRepository iPacienteAnuncioRepository;
	@Override
	public void insert(PacienteAnuncio pacienteAnuncio) {
		// TODO Auto-generated method stub
		iPacienteAnuncioRepository.save(pacienteAnuncio);
	}

	@Override
	public List<PacienteAnuncio> list() {
		// TODO Auto-generated method stub
		return iPacienteAnuncioRepository.findAll();
	}

	@Override
	public void delete(int idPacienteAnuncio) {
		// TODO Auto-generated method stub
		iPacienteAnuncioRepository.deleteById(idPacienteAnuncio);
	}
	@Override
	public Optional<PacienteAnuncio> listId(int idPacienteAnuncio) {
		// TODO Auto-generated method stub
		return iPacienteAnuncioRepository.findById(idPacienteAnuncio);
	}

	@Override
	public void update(PacienteAnuncio pacienteAnuncio) {
		// TODO Auto-generated method stub
		iPacienteAnuncioRepository.save(pacienteAnuncio);
	}
}
