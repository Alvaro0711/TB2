package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.serviceinterfaces.IPlanService;
import pe.edu.upc.entities.Plan;
import pe.edu.upc.repositories.IPlanRepository;

@Service
public class PlanServiceImpl implements IPlanService{
	
	@Autowired
	private IPlanRepository iPlanRepository;

	@Override
	public void insert(Plan pl) {
		iPlanRepository.save(pl);
	}

	@Override
	public List<Plan> list() {

		return iPlanRepository.findAll();
	}

	@Override
	public void delete(int idPlan) {
		iPlanRepository.deleteById(idPlan);
	}
	
	@Override
	public Optional<Plan> listId(int idPerson) {
		// TODO Auto-generated method stub
		return iPlanRepository.findById(idPerson);
	}

	@Override
	public void update(Plan person) {
		// TODO Auto-generated method stub
		iPlanRepository.save(person);
	}
}
