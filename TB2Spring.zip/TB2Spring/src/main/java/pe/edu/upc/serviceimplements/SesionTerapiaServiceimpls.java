package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.SesionTerapia;
import pe.edu.upc.repositories.ISesionTerapiaRepository;
import pe.edu.upc.serviceinterfaces.ISesionTerapiaService;
@Service
public class SesionTerapiaServiceimpls implements ISesionTerapiaService{
	@Autowired
	private ISesionTerapiaRepository sesionTerapiaRepository;
	
	@Override
	public void insert(SesionTerapia sesionTerapia) {
		// TODO Auto-generated method stub
		sesionTerapiaRepository.save(sesionTerapia);
	}

	@Override
	public List<SesionTerapia> list() {
		// TODO Auto-generated method stub
		return sesionTerapiaRepository.findAll();
	}

	@Override
	public void delete(int idSesion) {
		// TODO Auto-generated method stub
		sesionTerapiaRepository.deleteById(idSesion);
	}

	@Override
	public Optional<SesionTerapia> listId(int id) {
		// TODO Auto-generated method stub
		return sesionTerapiaRepository.findById(id);
	}

	@Override
	public void update(SesionTerapia sesionTerapia) {
		sesionTerapiaRepository.save(sesionTerapia);
		
	}

}
