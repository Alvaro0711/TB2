package pe.edu.upc.entities;

import java.util.Date;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "SesionTerapia")
public class SesionTerapia {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idSesionTerapia;
	@ManyToOne
	@JoinColumn(name = "idPaciente", nullable = true)
	private Paciente paciente;
	
	@ManyToOne
	@JoinColumn(name = "idPsicologo", nullable = true)
	private Psicologo psicologo;
	
	
	
	@OneToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.MERGE)
	@JoinColumn(name="idDocumento", referencedColumnName = "idDocumento", nullable=true)
	private DocumentoDeTrabajo documento;
	
	@OneToOne(fetch = FetchType.LAZY,optional = true, cascade = CascadeType.MERGE)
	@JoinColumn(name="idCalificacion", referencedColumnName = "idCalificacion", nullable=true)
	private CalificacionDeLaSesion calificacion;
	
	@OneToOne(fetch = FetchType.LAZY,optional = true, cascade = CascadeType.MERGE)
	@JoinColumn(name="idTest", referencedColumnName = "idTest", nullable=true)
	private Test test;

	
	@Column(name="titulo",nullable = false, length= 50)
	private String titulo;
	@Column(name="descripcion",nullable = false, length= 200)
	private String descripcion;
	@Column(name="inicioSesion",nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date inicioSesion;
	@Column(name="finSesion",nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date finSesion;
	@Column(name="Link",nullable = false, length= 50)
	private String Link;
	@Column(name="duracionEstmidada",nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date duracionEstmidada;
	
	public SesionTerapia() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SesionTerapia(int idSesionTerapia, Paciente paciente,
			Psicologo psicologo, DocumentoDeTrabajo documento,
			CalificacionDeLaSesion calificacion, Test test,
			String titulo, String descripcion, Date inicioSesion,
			Date finSesion, String link, Date duracionEstmidada) {
		super();
		this.idSesionTerapia = idSesionTerapia;
		this.paciente = paciente;
		this.psicologo = psicologo;
		this.documento = documento;
		this.calificacion = calificacion;
		this.test = test;
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.inicioSesion = inicioSesion;
		this.finSesion = finSesion;
		Link = link;
		this.duracionEstmidada = duracionEstmidada;
	}
	


	public SesionTerapia(DocumentoDeTrabajo documento, CalificacionDeLaSesion calificacion, Test test) {
		super();
		this.documento = documento;
		this.calificacion = calificacion;
		this.test = test;
	}

	public int getIdSesionTerapia() {
		return idSesionTerapia;
	}

	public void setIdSesionTerapia(int idSesionTerapia) {
		this.idSesionTerapia = idSesionTerapia;
	}

	public Paciente getPaciente() {
		return paciente;
	}


	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}



	public Psicologo getPsicologo() {
		return psicologo;
	}



	public void setPsicologo(Psicologo psicologo) {
		this.psicologo = psicologo;
	}

	public DocumentoDeTrabajo getDocumento() {
		return documento;
	}

	public void setDocumento(DocumentoDeTrabajo documento) {
		this.documento = documento;
	}

	public CalificacionDeLaSesion getCalificacion() {
		return calificacion;
	}


	public void setCalificacion(CalificacionDeLaSesion calificacion) {
		this.calificacion = calificacion;
	}


	public Test getTest() {
		return test;
	}

	public void setTest(Test test) {
		this.test = test;
	}


	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public Date getInicioSesion() {
		return inicioSesion;
	}

	public void setInicioSesion(Date inicioSesion) {
		this.inicioSesion = inicioSesion;
	}

	public Date getFinSesion() {
		return finSesion;
	}

	public void setFinSesion(Date finSesion) {
		this.finSesion = finSesion;
	}

	public String getLink() {
		return Link;
	}

	public void setLink(String link) {
		Link = link;
	}

	public Date getDuracionEstmidada() {
		return duracionEstmidada;
	}

	public void setDuracionEstmidada(Date duracionEstmidada) {
		this.duracionEstmidada = duracionEstmidada;
	}

	@Override
	public int hashCode() {
		return Objects.hash(Link, calificacion, descripcion, documento, duracionEstmidada, finSesion, idSesionTerapia,
				inicioSesion, paciente, psicologo, test, titulo);
	}







	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SesionTerapia other = (SesionTerapia) obj;
		return Objects.equals(Link, other.Link) && Objects.equals(calificacion, other.calificacion)
				&& Objects.equals(descripcion, other.descripcion) && Objects.equals(documento, other.documento)
				&& Objects.equals(duracionEstmidada, other.duracionEstmidada)
				&& Objects.equals(finSesion, other.finSesion) && idSesionTerapia == other.idSesionTerapia
				&& Objects.equals(inicioSesion, other.inicioSesion) && Objects.equals(paciente, other.paciente)
				&& Objects.equals(psicologo, other.psicologo) && Objects.equals(test, other.test)
				&& Objects.equals(titulo, other.titulo);
	}







	@Override
	public String toString() {
		return "SesionTerapia [idSesionTerapia=" + idSesionTerapia + ", paciente=" + paciente.getNombrePaciente() + ", psicologo="
				+ psicologo.getNombrePsicologo() + ", documento=" + documento.getIdDocumento() + ", calificacion=" + calificacion.getIdCalificacion() + ", test=" + test.getIdTest()
				+ ", titulo=" + titulo + ", descripcion=" + descripcion + ", inicioSesion=" + inicioSesion
				+ ", finSesion=" + finSesion + ", Link=" + Link + ", duracionEstmidada=" + duracionEstmidada + "]";
	}







	

	



	
	
	

	
	
	
}
