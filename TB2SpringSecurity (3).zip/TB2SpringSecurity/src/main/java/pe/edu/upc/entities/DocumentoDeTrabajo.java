package pe.edu.upc.entities;

import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DocumentoDeTrabajo")
public class DocumentoDeTrabajo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idDocumento;
	
	@Column(name="tipo",nullable = false, length= 30)
	private String tipo;
	@Column(name="titulo",nullable = false, length= 50)
	private String titulo;
	@Column(name="link",nullable = false, length= 50)
	private String link;
	
	@OneToOne(mappedBy = "documento", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private SesionTerapia sesionTerapia;
	
	public Boolean tieneSesion() {
		if(sesionTerapia==null) return false;
		else return false;		
	}
	
	
	public DocumentoDeTrabajo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DocumentoDeTrabajo(int idDocumento, String tipo, String titulo, String link) {
		super();
		this.idDocumento = idDocumento;
		this.tipo = tipo;
		this.titulo = titulo;
		this.link = link;
	}

	public int getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(int idDocumento) {
		this.idDocumento = idDocumento;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public SesionTerapia getSesionTerapia() {
		return sesionTerapia;
	}

	public void setSesionTerapia(SesionTerapia sesionTerapia) {
		this.sesionTerapia = sesionTerapia;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idDocumento, link, tipo, titulo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentoDeTrabajo other = (DocumentoDeTrabajo) obj;
		return idDocumento == other.idDocumento && Objects.equals(link, other.link) && Objects.equals(tipo, other.tipo)
				&& Objects.equals(titulo, other.titulo);
	}
	
	
	
}
