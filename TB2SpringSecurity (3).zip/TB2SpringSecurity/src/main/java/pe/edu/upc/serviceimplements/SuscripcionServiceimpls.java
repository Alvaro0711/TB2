package pe.edu.upc.serviceimplements;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.Suscripcion;
import pe.edu.upc.repositories.IPlanRepository;
import pe.edu.upc.repositories.ISuscripcionRepository;
import pe.edu.upc.serviceinterfaces.ISuscripcionService;

@Service
public class SuscripcionServiceimpls implements ISuscripcionService{
	@Autowired
	private ISuscripcionRepository suscripcionRepository;
	@Autowired
	private IPlanRepository planRepository;
	
	@Override
	public void insert(Suscripcion suscripcion) {
		suscripcionRepository.save(suscripcion);
		
	}

	@Override
	public List<Suscripcion> list() {
		return suscripcionRepository.findAll();
	}

	@Override
	public void delete(int idSuscripcion) {
		suscripcionRepository.deleteById(idSuscripcion);
	}

	@Override
	public Optional<Suscripcion> listId(int idSuscripcion) {
		return suscripcionRepository.findById(idSuscripcion);
	}

	@Override
	public void update(Suscripcion suscripcion) {
		suscripcionRepository.save(suscripcion);
	}

	@Override
	public Page<Suscripcion> getAll(Pageable pageable) {
		return suscripcionRepository.findAll(pageable);
	}

	@Override
	public List<Suscripcion> listNoInsertados() {
		List<Suscripcion> listaNoInsertados = new ArrayList<Suscripcion>();
		for (Suscripcion suscripcion : suscripcionRepository.findAll()) {
			if (suscripcion.getPaciente() == null)
				listaNoInsertados.add(suscripcion);
		}
		return listaNoInsertados;
	}

	@Override
	public void autocompletar(int cantidadInsertar) {
	}

	@Override
	public void deleteUnrelated() {
		List<Integer> idSuscripcionNoInsertador = new ArrayList<Integer>();
		for (Suscripcion suscripcion : listNoInsertados()) {
			idSuscripcionNoInsertador.add(suscripcion.getIdSuscripcion());
		}
		for (Integer idSuscripcion : idSuscripcionNoInsertador) {
			delete(idSuscripcion);
		}
	}

	@Override
	public List<Suscripcion> getAllbyText(String palabraClave) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Suscripcion> getAllbyTextPage(Pageable pageable, String palabraClave) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Suscripcion suscripcionNoInsertada() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getMontoTotal(Suscripcion suscripcion) {
		double meses=(double)(suscripcion.getMeses());
		double precio =planRepository.findById(suscripcion.getPlan().getIdPlan()).get().getPrecio();
		return meses*precio;
	}
	

	

}
