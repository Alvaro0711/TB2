package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entities.SesionTerapia;

public interface ISesionTerapiaService {
	public void insert(SesionTerapia sesionTerapia);
	public List<SesionTerapia> list();
	public void delete(int idSesion);
	public Optional<SesionTerapia> listId(int idSesion);
	public void update(SesionTerapia sesionTerapia);
}
