//package pe.edu.upc.serviceimplements;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import pe.edu.upc.entities.Anuncio;
//import pe.edu.upc.repositories.IAnuncioRepository;
//import pe.edu.upc.serviceinterfaces.IAnuncioService;
//@Service
//public class AnuncioServiceimpls implements IAnuncioService{
//	@Autowired
//	private IAnuncioRepository anuncioRepository;
//	@Override
//	public void insert(Anuncio anuncio) {
//		// TODO Auto-generated method stub
//		anuncioRepository.save(anuncio);
//	}
//
//	@Override
//	public List<Anuncio> list() {
//		// TODO Auto-generated method stub
//		return anuncioRepository.findAll();
//	}
//
//	@Override
//	public void delete(int idAnuncio) {
//		// TODO Auto-generated method stub
//		anuncioRepository.deleteById(idAnuncio);
//	}
//
//	@Override
//	public Optional<Anuncio> listId(int idAnuncio) {
//		// TODO Auto-generated method stub
//		return anuncioRepository.findById(idAnuncio);
//	}
//
//	@Override
//	public void update(Anuncio anuncio) {
//		anuncioRepository.save(anuncio);
//	}
//
//	
//
//}
