package pe.edu.upc.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import pe.edu.upc.entities.Rol;

public interface IRolService {
	public void insert(Rol rol);
	public List<Rol> list();
	public void delete(Long idRol);
	public Optional<Rol> listId(Long idRol);
	public void update(Rol rol);
	public Page<Rol> getAll(Pageable pageable);
}
