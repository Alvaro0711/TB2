package pe.edu.upc.serviceinterfaces;

import org.springframework.security.core.userdetails.UserDetailsService;

import pe.edu.upc.dto.UsuarioRegistroDTO;
import pe.edu.upc.entities.Usuario;

public interface UsuarioService extends UserDetailsService{
	public Usuario save(UsuarioRegistroDTO registroDTO);
}
