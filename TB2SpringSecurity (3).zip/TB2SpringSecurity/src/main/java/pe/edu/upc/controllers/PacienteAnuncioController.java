//package pe.edu.upc.controllers;
//
//import java.util.Map;
//import java.util.Optional;
//
//import javax.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import pe.edu.upc.entities.Anuncio;
//import pe.edu.upc.entities.PacienteAnuncio;
//import pe.edu.upc.serviceinterfaces.IPacienteAnuncioService;
//
//@Controller
//@RequestMapping("pacienteAnuncioController")
//public class PacienteAnuncioController {
//
//	@Autowired
//	private IPacienteAnuncioService pacienteAnuncioService;
//	
//	@GetMapping("/new")
//	public String newPacienteAnuncio(Model model) {
//		model.addAttribute("calificacion", new Anuncio());
//		return"pacienteAnuncio/frmRegister";
//	}
//	
//	@PostMapping("/save")
//	public String savePacienteAnuncio(@Valid PacienteAnuncio pacienteAnuncio, BindingResult binRes, Model model){
//		if(binRes.hasErrors()) {
//			model.addAttribute("error", "ocurrio un error: ");
//			return "pacienteAnuncio/frmRegister";
//		}else {
//			pacienteAnuncioService.insert(pacienteAnuncio);
//			model.addAttribute("mensaje", "se guardo correctamente");
//			return "redirect:/pacienteAnuncioController/new";
//		}  
//	}
//	
//	@GetMapping("/toList")
//	public String toListPacienteAnuncio(Model model) {
//		try {
//			model.addAttribute("listaPacuentesAnuncio", pacienteAnuncioService.list());
//		} catch (Exception e) {
//			model.addAttribute("error", e.getCause());
//		}
//		return "PacuentesAnuncio/frmList";
//	}
//	@RequestMapping("/delete")
//	public String deletePacienteAnuncio(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
//		try {
//			if(id!=null&&id>0) {
//				pacienteAnuncioService.delete(id);
//				model.put("listaPacuentesAnuncio", pacienteAnuncioService.list());//preguntar a la miss 
//			} 
//		} catch (Exception e) {
//			model.put("error", e.getMessage());
//		}
//		return "PacuentesAnuncio/frmList";  
//	}
//	@RequestMapping("goUpdate/{id}")
//	public String goUpdatePacienteAnuncio(@PathVariable int id, Model model) {
//		Optional<PacienteAnuncio> pacienteAnuncio =pacienteAnuncioService.listId(id);
//		model.addAttribute("psa", pacienteAnuncio.get());
//		return "pacienteAnuncio/frmUpdate";
//	}
//	@RequestMapping("update")
//	public String PacienteAnuncio(PacienteAnuncio pacienteAnuncio) {
//		pacienteAnuncioService.update(pacienteAnuncio);
//		return "redirect:/pacienteAnuncioController/toList";
//	}
//}
