package pe.edu.upc.controllers;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entities.Boleta;
import pe.edu.upc.entities.Suscripcion;
import pe.edu.upc.serviceinterfaces.IBoletaService;
import pe.edu.upc.serviceinterfaces.IPlanService;
import pe.edu.upc.serviceinterfaces.ISuscripcionService;

@Controller
@RequestMapping("suscripcionController")
public class SuscripcionController {
	@Autowired
	private ISuscripcionService suscripcionService;
	@Autowired
	private IPlanService planService;
	@Autowired
	private IBoletaService boletaService;

	@GetMapping("/new")
	public String newSuscripcion(Model model) {
		model.addAttribute("suscripcion", new Suscripcion());
		model.addAttribute("listaPlanes", planService.list());
		return "suscripcion/frmRegister";
	}

	@PostMapping("/save")
	public String saveSuscripcion(@Valid Suscripcion suscripcion, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			model.addAttribute("error", "ocurrio un error al guardar suscripcion: ");
		} else {
			Calendar calendar = Calendar.getInstance();
			Date date = calendar.getTime();
			Boleta nuevaBoleta = new Boleta();
			double monto=suscripcionService.getMontoTotal(suscripcion);
			nuevaBoleta.setDetalles("");
			nuevaBoleta.setFechaDePago(date);
			nuevaBoleta.setMonto(monto);
			nuevaBoleta.setMetodoDePago("Online-Visa");
			boletaService.insert(nuevaBoleta);
			suscripcion.setBoleta(nuevaBoleta);
			suscripcionService.insert(suscripcion);
			model.addAttribute("mensaje", "se guardo correctamente");
		}
		return "redirect:/suscripcionController/new";
	}

	@RequestMapping("/delete")
	public String deleteSuscripcion(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				suscripcionService.delete(id);
				model.put("listaSuscripcion", suscripcionService.list());// preguntar a la miss
			}
		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "redirect:/suscripcionController/toList";
	}

	@GetMapping("/toList")
	public String toListSucripcion(@RequestParam Map<String, Object> params, Model model) {
		try {
			model.addAttribute("listaSuscripcion", suscripcionService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getCause());
		}
		return "suscripcion/frmList";
	}

	@RequestMapping("/edit/{id}")
	public String editSuscripcion(@PathVariable int id, Model model) {
		Optional<Suscripcion> suscripcion = suscripcionService.listId(id);
		model.addAttribute("suscripcionEditar", suscripcion.get());
		return "suscripcion/frmUpdate";
	}

	@RequestMapping("/update")
	public String updateSuscripcion(Suscripcion suscripcion) {
		suscripcionService.update(suscripcion);
		return "redirect:/suscripcionController/toList";
	}
}