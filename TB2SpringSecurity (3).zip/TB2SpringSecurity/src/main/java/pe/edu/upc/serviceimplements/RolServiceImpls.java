package pe.edu.upc.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import pe.edu.upc.entities.Rol;
import pe.edu.upc.repositories.IRolRepository;
import pe.edu.upc.serviceinterfaces.IRolService;

@Service
public class RolServiceImpls implements IRolService{
	@Autowired
	private IRolRepository IRolRepository;
	
	@Override
	public void insert(Rol rol) {
		IRolRepository.save(rol);
	}

	@Override
	public List<Rol> list() {
		return IRolRepository.findAll();
	}

	@Override
	public void delete(Long idRol) {
		IRolRepository.deleteById(idRol);
	}

	@Override
	public Optional<Rol> listId(Long idRol) {
		return IRolRepository.findById(idRol);
	}

	@Override
	public void update(Rol rol) {
		IRolRepository.save(rol);
	}

	@Override
	public Page<Rol> getAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}
	
}