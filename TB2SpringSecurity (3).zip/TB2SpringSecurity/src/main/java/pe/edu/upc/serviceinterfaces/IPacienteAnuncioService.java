//package pe.edu.upc.serviceinterfaces;
//
//import java.util.List;
//import java.util.Optional;
//
//import pe.edu.upc.entities.PacienteAnuncio;
//
//public interface IPacienteAnuncioService {
//	public void insert(PacienteAnuncio pacienteAnuncio);
//	public List<PacienteAnuncio> list();
//	public void delete(int idPacienteAnuncio);
//	Optional<PacienteAnuncio> listId(int idPacienteAnuncio);
//	public void update(PacienteAnuncio pacienteAnuncio);
//}
