package pe.edu.upc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.entities.Test;

@Repository
public interface ITestRepository extends JpaRepository<Test, Integer> {
//	@Query("SELECT p FROM TEST p WHERE"
//			+ " CONCAT(p.nota,p.link)"
//			+ " LIKE %?1%")
	@Query("from Test p where p.nota like %:nota%")
	public List<Test> findByText(@Param("nota") String nota);
}
